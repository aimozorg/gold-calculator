-- بعد از ایجاد/پروvision حساب مدیر در Auth اجرا شود.
-- شماره را با شماره واقعی مدیر جایگزین کنید.
insert into public.admin_users (user_id, phone, is_active)
select id, private.normalize_phone(phone), true
from auth.users
where phone = private.normalize_phone('+98XXXXXXXXXX')
on conflict (user_id) do update set
  phone = excluded.phone,
  is_active = true;
