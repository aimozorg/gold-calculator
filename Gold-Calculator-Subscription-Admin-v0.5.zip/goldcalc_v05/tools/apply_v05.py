from pathlib import Path
import re

p = Path('lib/main.dart')
s = p.read_text()

imports = """import 'services/admin_service.dart';
import 'screens/admin_panel.dart';
import 'screens/activation_screen.dart';
import 'screens/phone_auth_screen.dart';
"""
anchor = "import 'services/supabase_service.dart';\n"
if imports not in s:
    s = s.replace(anchor, anchor + imports, 1)

start = s.find('class AppGate extends StatelessWidget')
end = s.find('class CalculatorHome extends StatefulWidget')
if start == -1 or end == -1 or end <= start:
    raise SystemExit('Could not locate AppGate..CalculatorHome block')

block = r'''class AppGate extends StatelessWidget {
  const AppGate({super.key});

  @override
  Widget build(BuildContext context) {
    if (supabaseUrl.isEmpty || supabasePublishableKey.isEmpty) {
      return SubscriptionGate.localPreview();
    }

    return StreamBuilder<AuthState>(
      stream: SupabaseService.auth.onAuthStateChange,
      builder: (context, snapshot) {
        if (SupabaseService.auth.currentUser == null) {
          return const PhoneAuthScreen();
        }

        return const _RoleGate();
      },
    );
  }
}

class _RoleGate extends StatefulWidget {
  const _RoleGate();
  @override
  State<_RoleGate> createState() => _RoleGateState();
}

class _RoleGateState extends State<_RoleGate> {
  late Future<bool> adminFuture;

  @override
  void initState() {
    super.initState();
    adminFuture = AdminService(SupabaseService.client).isAdmin();
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<bool>(
        future: adminFuture,
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }

          if (snap.data == true) {
            return AdminPanel(
              onOpenCalculator: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => CalculatorHome(
                      plan: 'مدیر',
                      onDeactivate: () {},
                    ),
                  ),
                );
              },
            );
          }

          return const SubscriptionGate();
        },
      );
}

class SubscriptionGate extends StatefulWidget {
  final bool preview;
  const SubscriptionGate({super.key}) : preview = false;
  const SubscriptionGate.localPreview({super.key}) : preview = true;

  @override
  State<SubscriptionGate> createState() => _SubscriptionGateState();
}

class _SubscriptionGateState extends State<SubscriptionGate> {
  late Future<SubscriptionState> state;

  @override
  void initState() {
    super.initState();
    state = widget.preview
        ? Future.value(const SubscriptionState(active: true, plan: 'پیش‌نمایش'))
        : SubscriptionService(SupabaseService.client).current();
  }

  void refresh() {
    setState(() {
      state = SubscriptionService(SupabaseService.client).current();
    });
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<SubscriptionState>(
        future: state,
        builder: (context, snap) {
          if (snap.hasError) {
            return _errorScreen(snap.error.toString());
          }
          if (!snap.hasData) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }

          final s = snap.data!;
          if (!s.active) {
            return Stack(
              children: [
                ActivationScreen(onActivated: refresh),
                if (!widget.preview)
                  Positioned(
                    top: 20,
                    left: 20,
                    child: SafeArea(
                      child: IconButton(
                        tooltip: 'خروج',
                        onPressed: () => SupabaseService.auth.signOut(),
                        icon: const Icon(Icons.logout),
                      ),
                    ),
                  ),
              ],
            );
          }

          return CalculatorHome(plan: s.plan, onDeactivate: () {});
        },
      );

  Widget _errorScreen(String error) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          body: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.error_outline, size: 52),
                        const SizedBox(height: 12),
                        const Text(
                          'خطا در بررسی اشتراک',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(error, textAlign: TextAlign.center),
                        const SizedBox(height: 18),
                        FilledButton.icon(
                          onPressed: refresh,
                          icon: const Icon(Icons.refresh),
                          label: const Text('تلاش دوباره'),
                        ),
                        TextButton(
                          onPressed: () => SupabaseService.auth.signOut(),
                          child: const Text('خروج'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
}

'''
s = s[:start] + block + s[end:]
p.write_text(s)
print('APP_GATE_PATCHED')
