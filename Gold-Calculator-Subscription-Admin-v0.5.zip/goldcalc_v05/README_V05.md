# Gold Calculator — Subscription/Admin v0.5

این بسته برای اضافه‌کردن مدل اشتراکی دستی و پنل مدیریت به پروژه فعلی Gold Calculator است.

## مدل کسب‌وکار

- ورود مشتری: شماره موبایل + OTP پیامکی.
- فقط شماره‌هایی که مدیر در Whitelist قرار می‌دهد می‌توانند وارد چرخه استفاده شوند.
- مدیر پس از دریافت/تأیید فیش واریزی، از پنل یکی از پلن‌های 1، 3، 6 یا 12 ماهه را انتخاب می‌کند و کد فعال‌سازی می‌سازد.
- کد در دیتابیس به صورت hash ذخیره می‌شود و فقط متن خام کد در همان لحظه به مدیر نمایش داده می‌شود.
- مشتری کد را داخل اپ وارد می‌کند.
- شروع اشتراک در لحظه Redeem است؛ برای تمدیدِ اشتراک فعال، مدت جدید بعد از زمان انقضای فعلی اضافه می‌شود تا مشتری زمان فعال خود را از دست ندهد.
- بعد از expires_at، ماشین‌حساب قفل می‌شود.
- محاسبات خود اپ همچنان Offline-first هستند؛ Backend فقط برای احراز هویت/مجوز/اشتراک استفاده می‌شود.

## فایل‌ها

- `supabase/migrations/0002_admin_subscription_v05.sql`
- `supabase/functions/admin-whitelist/index.ts`
- `supabase/functions/admin-create-activation/index.ts`
- `supabase/functions/redeem-activation/index.ts`
- `supabase/functions/subscription-status/index.ts`
- `supabase/functions/admin-dashboard/index.ts`
- `supabase/functions/_shared/helpers.ts`
- `lib/services/phone_auth_service.dart`
- `lib/services/subscription_service.dart`
- `lib/services/admin_service.dart`
- `lib/screens/phone_auth_screen.dart`
- `lib/screens/activation_screen.dart`
- `lib/screens/admin_panel.dart`
- `tools/apply_v05.py`

## 1) فعال‌کردن Phone Auth در Supabase

در Dashboard پروژه:

Authentication → Providers → Phone

را فعال کن و SMS provider را تنظیم کن. Supabase Phone Auth با OTP پیامکی کار می‌کند و به provider پیامک نیاز دارد.

## 2) Migration

در SQL Editor، بهتر است از مسیر migration استفاده کنیم. اگر CLI هنوز متصل نشده:

```bash
npm install supabase --save-dev
npx supabase login
npx supabase link --project-ref YOUR_PROJECT_REF
```

بعد:

```bash
npx supabase db push
```

قبل از `db push` اگر جدول‌ها را مستقیماً در Dashboard تغییر داده‌ای، بهتر است ابتدا schema فعلی را به migration محلی بکشیم (`npx supabase db pull`) تا تاریخچه از بین نرود.

## 3) Bootstrap مدیر اولیه

ابتدا یک حساب شماره‌ای برای شماره مدیرت در Supabase Authentication بساز/پروvision کن. سپس ID همان کاربر را در SQL زیر قرار بده:

```sql
insert into public.admin_users (user_id, phone, is_active)
select id, private.normalize_phone(phone), true
from auth.users
where phone = private.normalize_phone('+98XXXXXXXXXX')
on conflict (user_id) do update set
  phone = excluded.phone,
  is_active = true;
```

شماره را با شماره واقعی خودت جایگزین کن.

پس از آن، مدیر می‌تواند از داخل اپ مشتری‌ها را Whitelist کند. Function `admin-whitelist` برای شماره مجاز، حساب Auth را هم provision می‌کند تا OTP بعداً با `shouldCreateUser: false` ارسال شود.

## 4) Deploy Edge Functions

در Codespace، داخل ریشه پروژه:

```bash
npx supabase functions deploy admin-whitelist
npx supabase functions deploy admin-create-activation
npx supabase functions deploy redeem-activation
npx supabase functions deploy subscription-status
npx supabase functions deploy admin-dashboard
```

همه این Functionها با JWT کاربر اجرا می‌شوند و کلیدهای secret فقط سمت سرور استفاده می‌شوند.

## 5) Flutter integration

فایل‌های Dart این بسته را در همان مسیرهای پروژه کپی کن.

سپس اسکریپت patch را اجرا کن:

```bash
python3 tools/apply_v05.py
```

بعد:

```bash
flutter pub get
dart format lib
flutter analyze
flutter test
```

## 6) اجرای رفتار نهایی

### مشتری

1. مدیر شماره مشتری را Whitelist می‌کند.
2. سیستم کاربر Auth را provision می‌کند.
3. مشتری با همان شماره OTP می‌گیرد.
4. تا زمانی که کد فعال‌سازی Redeem نشده، Calculator قفل است.
5. کد صادرشده را وارد می‌کند.
6. اشتراک فعال می‌شود.
7. بعد از expiration، Calculator دوباره قفل می‌شود.

### مدیر

با شماره‌ای که در `admin_users` ثبت شده وارد می‌شود و به جای Calculator، Admin Panel را می‌بیند:

- تعداد Whitelist فعال
- اشتراک‌های فعال
- انقضای 7 روز آینده
- افزودن/غیرفعال‌کردن شماره
- ساخت کد 1/3/6/12 ماهه
- کپی کد برای ارسال به مشتری

## نکات امنیتی

- `service_role` / secret key هرگز داخل Flutter قرار نگیرد.
- متن خام Activation Code در دیتابیس ذخیره نمی‌شود.
- کاربر عادی مستقیماً نمی‌تواند subscriptions، activation_codes یا admin_users را تغییر دهد.
- اعتبار اشتراک از Backend بررسی می‌شود و `server_now` نیز برگردانده می‌شود.
