import { corsHeaders, json, requireUser, isAdmin } from '../_shared/helpers.ts'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  try {
    const { user, admin } = await requireUser(req)
    if (!(await isAdmin(admin, user.id))) return json({ error: 'ADMIN_REQUIRED' }, 403)

    const [{ count: whitelistCount }, { count: activeCount }, { count: expiringCount }, { data: recentSubscriptions }] = await Promise.all([
      admin.from('access_whitelist').select('*', { count: 'exact', head: true }).eq('is_allowed', true),
      admin.from('subscriptions').select('*', { count: 'exact', head: true }).eq('status', 'active').gt('expires_at', new Date().toISOString()),
      admin.from('subscriptions').select('*', { count: 'exact', head: true }).eq('status', 'active').gt('expires_at', new Date().toISOString()).lte('expires_at', new Date(Date.now() + 7 * 86400000).toISOString()),
      admin.from('subscriptions').select('phone,plan,duration_months,status,activated_at,expires_at').order('created_at', { ascending: false }).limit(50),
    ])

    return json({
      ok: true,
      summary: {
        whitelist: whitelistCount ?? 0,
        active: activeCount ?? 0,
        expiring7d: expiringCount ?? 0,
      },
      recent: recentSubscriptions ?? [],
    })
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e)
    return json({ error: message }, message === 'AUTH_REQUIRED' ? 401 : 400)
  }
})
