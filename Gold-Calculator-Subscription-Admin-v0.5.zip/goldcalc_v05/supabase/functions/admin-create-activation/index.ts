import { corsHeaders, json, requireUser, isAdmin, normalizePhone, randomCode, sha256Hex, planSpec } from '../_shared/helpers.ts'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  try {
    const { user, admin } = await requireUser(req)
    if (!(await isAdmin(admin, user.id))) return json({ error: 'ADMIN_REQUIRED' }, 403)

    const body = await req.json()
    const phone = normalizePhone(String(body.phone ?? ''))
    const plan = String(body.plan ?? '')
    const note = body.note == null ? null : String(body.note)
    const { durationMonths } = planSpec(plan)

    if (!phone) return json({ error: 'PHONE_REQUIRED' }, 400)

    const { data: whitelist, error: whitelistError } = await admin
      .from('access_whitelist')
      .select('phone,is_allowed')
      .eq('phone', phone)
      .maybeSingle()
    if (whitelistError) throw whitelistError
    if (!whitelist?.is_allowed) return json({ error: 'PHONE_NOT_WHITELISTED' }, 400)

    await admin.from('activation_codes').update({ status: 'revoked' })
      .eq('phone', phone).eq('status', 'unused')

    const rawCode = randomCode()
    const codeHash = await sha256Hex(rawCode.toLowerCase())

    const { data, error } = await admin
      .from('activation_codes')
      .insert({
        phone,
        code_hash: codeHash,
        plan,
        duration_months: durationMonths,
        status: 'unused',
        created_by: user.id,
        note,
      })
      .select('id,phone,plan,duration_months,status,created_at,note')
      .single()
    if (error) throw error

    await admin.from('subscription_audit_log').insert({
      phone,
      action: 'activation_created',
      plan,
      duration_months: durationMonths,
      activation_code_id: data.id,
      performed_by: user.id,
      metadata: { note },
    })

    return json({ ok: true, code: rawCode, activation: data })
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e)
    return json({ error: message }, message === 'AUTH_REQUIRED' ? 401 : 400)
  }
})
