import { corsHeaders, json, getAdminClient, requireUser, isAdmin, normalizePhone } from '../_shared/helpers.ts'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  try {
    const { user, admin } = await requireUser(req)
    if (!(await isAdmin(admin, user.id))) return json({ error: 'ADMIN_REQUIRED' }, 403)

    const body = await req.json()
    const phone = normalizePhone(String(body.phone ?? ''))
    const allowed = body.is_allowed !== false
    const note = body.note == null ? null : String(body.note)
    if (!phone) return json({ error: 'PHONE_REQUIRED' }, 400)

    const { data, error } = await admin
      .from('access_whitelist')
      .upsert({ phone, is_allowed: allowed, note, added_by: user.id }, { onConflict: 'phone' })
      .select('id,phone,is_allowed,note,created_at,updated_at')
      .single()
    if (error) throw error

    if (allowed) {
      const { error: provisionError } = await admin.auth.admin.createUser({
        phone,
        phone_confirm: false,
      })
      if (provisionError && !provisionError.message.toLowerCase().includes('already')) {
        throw provisionError
      }
    }

    if (!allowed) {
      await admin.from('activation_codes').update({ status: 'revoked' }).eq('phone', phone).eq('status', 'unused')
    }

    await admin.from('subscription_audit_log').insert({
      phone,
      action: allowed ? 'whitelist_added' : 'whitelist_disabled',
      performed_by: user.id,
      metadata: { note },
    })

    return json({ ok: true, whitelist: data })
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e)
    return json({ error: message }, message === 'AUTH_REQUIRED' ? 401 : 400)
  }
})
