import { corsHeaders, json, requireUser } from '../_shared/helpers.ts'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  try {
    const { user, admin } = await requireUser(req)
    const { data, error } = await admin.rpc('subscription_status', { p_user_id: user.id })
    if (error) throw error
    return json({ ok: true, subscription: data ?? { active: false, plan: 'none', status: 'inactive' } })
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e)
    return json({ error: message }, message === 'AUTH_REQUIRED' ? 401 : 400)
  }
})
