import { createClient } from 'npm:@supabase/supabase-js@2'

export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

export function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json; charset=utf-8' },
  })
}

export function getAdminClient() {
  const url = Deno.env.get('SUPABASE_URL') ?? ''
  let secret = Deno.env.get('SUPABASE_SECRET_KEY') ?? Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  if (!secret) {
    const raw = Deno.env.get('SUPABASE_SECRET_KEYS')
    if (raw) {
      try {
        const parsed = JSON.parse(raw) as Record<string, string>
        secret = Object.values(parsed)[0] ?? ''
      } catch (_) {
        // Fall through to the explicit missing-secret error below.
      }
    }
  }
  if (!url || !secret) throw new Error('Supabase secret configuration is missing')
  return createClient(url, secret, { auth: { persistSession: false, autoRefreshToken: false } })
}

export function getAccessToken(req: Request) {
  const header = req.headers.get('Authorization') ?? ''
  if (!header.startsWith('Bearer ')) return null
  return header.slice('Bearer '.length).trim()
}

export async function requireUser(req: Request) {
  const token = getAccessToken(req)
  if (!token) throw new Error('AUTH_REQUIRED')
  const admin = getAdminClient()
  const { data, error } = await admin.auth.getUser(token)
  if (error || !data.user) throw new Error('AUTH_REQUIRED')
  return { user: data.user, admin }
}

export function normalizePhone(phone: string) {
  let v = (phone ?? '').trim()
    .replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/[\s()-]/g, '')

  if (v.startsWith('0098')) v = '+' + v.slice(2)
  else if (v.startsWith('09')) v = '+98' + v.slice(1)
  else if (v.startsWith('9')) v = '+98' + v

  return v
}

export async function isAdmin(admin: ReturnType<typeof getAdminClient>, userId: string) {
  const { data, error } = await admin
    .from('admin_users')
    .select('user_id,is_active')
    .eq('user_id', userId)
    .eq('is_active', true)
    .maybeSingle()
  if (error) throw error
  return !!data
}

export function randomCode(length = 12) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  const bytes = new Uint8Array(length)
  crypto.getRandomValues(bytes)
  let out = ''
  for (const b of bytes) out += alphabet[b % alphabet.length]
  return `${out.slice(0, 4)}-${out.slice(4, 8)}-${out.slice(8)}`
}

export async function sha256Hex(value: string) {
  const buffer = new TextEncoder().encode(value)
  const hash = await crypto.subtle.digest('SHA-256', buffer)
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('')
}

export function planSpec(plan: string) {
  switch (plan) {
    case 'monthly': return { durationMonths: 1 }
    case 'quarterly': return { durationMonths: 3 }
    case 'semiannual': return { durationMonths: 6 }
    case 'annual': return { durationMonths: 12 }
    default: throw new Error('INVALID_PLAN')
  }
}
