import { corsHeaders, json, requireUser } from '../_shared/helpers.ts'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  try {
    const { user, admin } = await requireUser(req)
    const body = await req.json()
    const code = String(body.code ?? '').trim()
    if (!code) return json({ error: 'CODE_REQUIRED' }, 400)

    const { data, error } = await admin.rpc('redeem_activation_code', {
      p_user_id: user.id,
      p_code: code,
    })
    if (error) throw error

    return json({ ok: true, subscription: data })
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e)
    return json({ error: message }, message === 'AUTH_REQUIRED' ? 401 : 400)
  }
})
