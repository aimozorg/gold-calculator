import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/subscription_service.dart';

class ActivationScreen extends StatefulWidget {
  final VoidCallback onActivated;
  const ActivationScreen({super.key, required this.onActivated});
  @override State<ActivationScreen> createState() => _ActivationScreenState();
}

class _ActivationScreenState extends State<ActivationScreen> {
  final code = TextEditingController();
  bool loading = false;
  String? error;

  late final SubscriptionService service = SubscriptionService(Supabase.instance.client);

  Future<void> redeem() async {
    setState(() { loading = true; error = null; });
    try {
      await service.redeem(code.text);
      widget.onActivated();
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Bad state: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void dispose() { code.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.lock_outline_rounded, size: 54),
                    const SizedBox(height: 12),
                    const Text('اشتراک فعال نیست', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 10),
                    const Text('کد فعال‌سازی دریافت‌شده از پشتیبانی را وارد کنید.', textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    TextField(
                      controller: code,
                      textCapitalization: TextCapitalization.characters,
                      decoration: const InputDecoration(labelText: 'کد فعال‌سازی'),
                    ),
                    if (error != null) ...[
                      const SizedBox(height: 10),
                      Text(error!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center),
                    ],
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: loading ? null : redeem,
                      icon: const Icon(Icons.key_outlined),
                      label: Text(loading ? 'در حال فعال‌سازی…' : 'فعال‌سازی اشتراک'),
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton(
                      onPressed: () => showDialog<void>(
                        context: context,
                        builder: (_) => const AlertDialog(
                          title: Text('خرید اشتراک'),
                          content: Text('برای خرید اشتراک با پشتیبانی تماس بگیرید و فیش واریزی را ارسال کنید. پس از تأیید، کد فعال‌سازی برای شماره شما صادر می‌شود.'),
                        ),
                      ),
                      child: const Text('نحوه خرید اشتراک'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  );
}

