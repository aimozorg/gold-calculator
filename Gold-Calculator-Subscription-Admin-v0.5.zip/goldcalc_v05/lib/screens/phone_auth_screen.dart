import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/phone_auth_service.dart';

class PhoneAuthScreen extends StatefulWidget {
  const PhoneAuthScreen({super.key});
  @override State<PhoneAuthScreen> createState() => _PhoneAuthScreenState();
}

class _PhoneAuthScreenState extends State<PhoneAuthScreen> {
  final phone = TextEditingController();
  final otp = TextEditingController();
  bool codeSent = false;
  bool loading = false;
  String? error;

  late final PhoneAuthService auth = PhoneAuthService(Supabase.instance.client);

  Future<void> send() async {
    setState(() { loading = true; error = null; });
    try {
      await auth.sendOtp(phone.text);
      setState(() => codeSent = true);
    } on AuthException catch (e) {
      setState(() => error = e.message);
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> verify() async {
    setState(() { loading = true; error = null; });
    try {
      await auth.verifyOtp(phone: phone.text, token: otp.text);
    } on AuthException catch (e) {
      setState(() => error = e.message);
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void dispose() { phone.dispose(); otp.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 460),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.phone_android_rounded, size: 52),
                    const SizedBox(height: 12),
                    Text(codeSent ? 'کد تأیید را وارد کنید' : 'ورود با شماره موبایل',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 18),
                    TextField(
                      controller: phone,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(labelText: 'شماره موبایل'),
                    ),
                    if (codeSent) ...[
                      const SizedBox(height: 12),
                      TextField(
                        controller: otp,
                        keyboardType: TextInputType.number,
                        maxLength: 6,
                        decoration: const InputDecoration(labelText: 'کد ۶ رقمی پیامک شده'),
                      ),
                    ],
                    if (error != null) ...[
                      const SizedBox(height: 10),
                      Text(error!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center),
                    ],
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: loading ? null : (codeSent ? verify : send),
                      icon: Icon(codeSent ? Icons.verified_outlined : Icons.sms_outlined),
                      label: Text(loading ? 'در حال پردازش…' : (codeSent ? 'تأیید و ورود' : 'ارسال کد ورود')),
                    ),
                    if (codeSent)
                      TextButton(
                        onPressed: loading ? null : () => setState(() { codeSent = false; otp.clear(); }),
                        child: const Text('تغییر شماره'),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  );
}
