import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/admin_service.dart';

class AdminPanel extends StatefulWidget {
  final VoidCallback onOpenCalculator;
  const AdminPanel({super.key, required this.onOpenCalculator});
  @override State<AdminPanel> createState() => _AdminPanelState();
}

class _AdminPanelState extends State<AdminPanel> {
  final phone = TextEditingController();
  final note = TextEditingController();
  late final AdminService admin = AdminService(Supabase.instance.client);
  String plan = 'monthly';
  bool allowed = true;
  bool busy = false;
  Map<String, dynamic>? dashboard;
  String? message;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try { setState(() => dashboard = await admin.dashboard()); } catch (e) { setState(() => message = e.toString()); }
  }

  Future<void> _whitelist() async {
    setState(() { busy = true; message = null; });
    try {
      await admin.whitelist(phone: phone.text, allowed: allowed, note: note.text.trim().isEmpty ? null : note.text.trim());
      setState(() => message = allowed ? 'شماره به Whitelist اضافه شد.' : 'دسترسی شماره غیرفعال شد.');
      await _load();
    } catch (e) { setState(() => message = e.toString().replaceFirst('Bad state: ', '')); }
    finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> _createCode() async {
    setState(() { busy = true; message = null; });
    try {
      final data = await admin.createActivation(phone: phone.text, plan: plan, note: note.text.trim().isEmpty ? null : note.text.trim());
      final code = data['code']?.toString() ?? '';
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('کد فعال‌سازی ایجاد شد'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            SelectableText(code, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 2)),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: code));
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('کد کپی شد.')));
                }
              },
              icon: const Icon(Icons.copy_outlined),
              label: const Text('کپی کد'),
            ),
          ]),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('بستن'))],
        ),
      );
    } catch (e) { setState(() => message = e.toString().replaceFirst('Bad state: ', '')); }
    finally { if (mounted) setState(() => busy = false); }
  }

  @override
  void dispose() { phone.dispose(); note.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('پنل مدیریت')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (dashboard != null)
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                _stat('Whitelist فعال', '${dashboard!['summary']['whitelist']}'),
                _stat('اشتراک فعال', '${dashboard!['summary']['active']}'),
                _stat('انقضای ۷ روز آینده', '${dashboard!['summary']['expiring7d']}'),
              ],
            ),
          const SizedBox(height: 16),
          Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('مدیریت مشتری', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره موبایل مشتری')),
            const SizedBox(height: 10),
            TextField(controller: note, decoration: const InputDecoration(labelText: 'یادداشت (اختیاری)')),
            const SizedBox(height: 12),
            Wrap(spacing: 10, runSpacing: 10, children: [
              FilledButton.icon(onPressed: busy ? null : _whitelist, icon: const Icon(Icons.person_add_alt_1), label: const Text('افزودن به Whitelist')),
              OutlinedButton.icon(onPressed: busy ? null : () { setState(() => allowed = false); _whitelist(); }, icon: const Icon(Icons.block), label: const Text('غیرفعال کردن')),
            ]),
          ]))),
          const SizedBox(height: 16),
          Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('صدور کد فعال‌سازی', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(value: plan, items: const [
              DropdownMenuItem(value: 'monthly', child: Text('۱ ماهه')),
              DropdownMenuItem(value: 'quarterly', child: Text('۳ ماهه')),
              DropdownMenuItem(value: 'semiannual', child: Text('۶ ماهه')),
              DropdownMenuItem(value: 'annual', child: Text('۱ ساله')),
            ], onChanged: busy ? null : (v) => setState(() => plan = v ?? 'monthly'), decoration: const InputDecoration(labelText: 'مدت اشتراک')),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: busy ? null : _createCode, icon: const Icon(Icons.key_outlined), label: const Text('ایجاد کد فعال‌سازی')),
          ]))),
          if (message != null) ...[
            const SizedBox(height: 12),
            Text(message!, textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w700)),
          ],
          const SizedBox(height: 16),
          OutlinedButton.icon(onPressed: widget.onOpenCalculator, icon: const Icon(Icons.calculate_outlined), label: const Text('باز کردن ماشین‌حساب')),
        ],
      ),
    ),
  );

  Widget _stat(String title, String value) => SizedBox(width: 180, child: Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [Text(value, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(title)]))));
}

