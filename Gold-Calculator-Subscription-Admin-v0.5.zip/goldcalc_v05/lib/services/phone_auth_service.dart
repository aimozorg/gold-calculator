import 'package:supabase_flutter/supabase_flutter.dart';

class PhoneAuthService {
  final SupabaseClient client;
  PhoneAuthService(this.client);

  static String normalizePhone(String value) {
    var v = value.trim()
        .replaceAll(RegExp(r'[\s\-()]'), '')
        .replaceAll('۰', '0').replaceAll('۱', '1').replaceAll('۲', '2')
        .replaceAll('۳', '3').replaceAll('۴', '4').replaceAll('۵', '5')
        .replaceAll('۶', '6').replaceAll('۷', '7').replaceAll('۸', '8')
        .replaceAll('۹', '9');
    if (v.startsWith('0098')) v = '+${v.substring(2)}';
    if (v.startsWith('09')) v = '+98${v.substring(1)}';
    if (RegExp(r'^9\d{9}$').hasMatch(v)) v = '+98$v';
    return v;
  }

  Future<void> sendOtp(String phone) async {
    await client.auth.signInWithOtp(
      phone: normalizePhone(phone),
      shouldCreateUser: false,
    );
  }

  Future<AuthResponse> verifyOtp({required String phone, required String token}) {
    return client.auth.verifyOTP(
      phone: normalizePhone(phone),
      token: token.trim(),
      type: OtpType.sms,
    );
  }
}
