import 'package:supabase_flutter/supabase_flutter.dart';

class SubscriptionState {
  final bool active;
  final String plan;
  final String status;
  final DateTime? activatedAt;
  final DateTime? expiresAt;
  final DateTime? serverNow;

  const SubscriptionState({
    required this.active,
    this.plan = 'none',
    this.status = 'inactive',
    this.activatedAt,
    this.expiresAt,
    this.serverNow,
  });
}

class SubscriptionService {
  final SupabaseClient client;
  SubscriptionService(this.client);

  Future<SubscriptionState> current() async {
    final response = await client.functions.invoke('subscription-status');
    final data = Map<String, dynamic>.from(response.data as Map);
    if (data['error'] != null) {
      throw StateError(data['error'].toString());
    }
    final raw = Map<String, dynamic>.from(data['subscription'] as Map? ?? {});
    DateTime? parse(Object? value) => value == null ? null : DateTime.tryParse(value.toString())?.toUtc();
    return SubscriptionState(
      active: raw['active'] == true,
      plan: raw['plan']?.toString() ?? 'none',
      status: raw['status']?.toString() ?? 'inactive',
      activatedAt: parse(raw['activated_at']),
      expiresAt: parse(raw['expires_at']),
      serverNow: parse(raw['server_now']),
    );
  }

  Future<Map<String, dynamic>> redeem(String code) async {
    final response = await client.functions.invoke(
      'redeem-activation',
      body: {'code': code.trim()},
    );
    final data = Map<String, dynamic>.from(response.data as Map);
    if (data['error'] != null) throw StateError(data['error'].toString());
    return data;
  }
}
