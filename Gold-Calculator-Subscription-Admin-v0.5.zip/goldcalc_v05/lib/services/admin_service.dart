import 'package:supabase_flutter/supabase_flutter.dart';

class AdminService {
  final SupabaseClient client;
  AdminService(this.client);

  Future<bool> isAdmin() async {
    try {
      final response = await client.functions.invoke('admin-dashboard');
      return response.status == 200 && (response.data as Map?)?['ok'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<Map<String, dynamic>> dashboard() async {
    final response = await client.functions.invoke('admin-dashboard');
    if (response.status != 200) {
      throw StateError(((response.data as Map?)?['error'])?.toString() ?? 'دسترسی مدیر لازم است');
    }
    return Map<String, dynamic>.from(response.data as Map);
  }

  Future<Map<String, dynamic>> whitelist({
    required String phone,
    bool allowed = true,
    String? note,
  }) async {
    final response = await client.functions.invoke(
      'admin-whitelist',
      body: {'phone': phone, 'is_allowed': allowed, 'note': note},
    );
    final data = Map<String, dynamic>.from(response.data as Map);
    if (data['error'] != null) throw StateError(data['error'].toString());
    return data;
  }

  Future<Map<String, dynamic>> createActivation({
    required String phone,
    required String plan,
    String? note,
  }) async {
    final response = await client.functions.invoke(
      'admin-create-activation',
      body: {'phone': phone, 'plan': plan, 'note': note},
    );
    final data = Map<String, dynamic>.from(response.data as Map);
    if (data['error'] != null) throw StateError(data['error'].toString());
    return data;
  }
}
